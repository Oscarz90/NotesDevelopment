yajsw-beta-12.06

    * Change: update libs: netty-all-4.0.35.Final, commons-cli-1.3.1, commons-collections-3.2.2, commons-configuration2-2.0
    * Bug: No application logs on yajsw 11.11 / Ubuntu 14.04
    * Bug: Windows 10 DELAYED_AUTO_START
